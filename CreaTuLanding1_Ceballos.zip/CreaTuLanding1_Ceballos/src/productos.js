const productos = [
    {
        id: 1,
        nombre: "Producto 1",
        precio: 100,
        img: "",
    },
    {
        id: 2,
        nombre: "Producto 2",
        precio: 120,
        img: "",
    },
    {
        id: 3,
        nombre: "Producto 3",
        precio: 50,
        img: "",
    },
    {
        id: 4,
        nombre: "Producto 4",
        precio: 70,
        img: "",
    },
];