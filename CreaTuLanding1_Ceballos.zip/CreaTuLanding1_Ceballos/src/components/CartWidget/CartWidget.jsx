import './CartWidget.css';

function CartWidget() {
    return (
        <p>Icono carrito (4)</p>
    );
};

export default CartWidget;